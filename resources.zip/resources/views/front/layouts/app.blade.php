@include('front.layouts._partials.header')

@yield('content')

@include('front.layouts._partials.footer')
