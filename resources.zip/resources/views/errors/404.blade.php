<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <style media="screen">
    .center{
      text-align: center;
      padding-top: 205px;
    }
  </style>
  <body>

<div class="center">
  <h2>404</h2>
  <h2>NOT FOUND</h2>

</div>

  </body>
</html>
