 

	<div class="footer_section" style="background-image: url('images/slider/7.jpg');">
		<div class="container p_tb20 footer">
			<div class="all_footer">
				<div class="row">
					<div class="col-lg-8 offset-lg-2 col-md-12 col-12 m_b25">
						<div class="text-center subscribe_form">
							<h2 class="font_28 white subs_title">subscribe us</h2>
							<form action="" method="post" class="form form-horizontal">
							<div class="row form-group">
								<div class="col-lg-5 col-md-5 col-sm-12 p_tb5">
									<input type="text" placeholder="Full Name" required class="form-control form-control-sm rounded-0">
								</div>
								<div class="col-lg-5 col-md-5 col-sm-12 p_tb5">
									<input type="email" placeholder="Email Address" required class="form-control form-control-sm rounded-0 required">
								</div>
								<div class="col-lg-2 col-md-2 col-sm-12 p_tb5 float-right text-right">
									<button type="submit" class="btn subscribe_us rounded-0 btn-sm">submit</button>
								</div>

							</div>
						</form>
						</div>
					</div>
				</div>


				<div class="row">
					<div class="col-lg-3 col-md-6 col-sm-12 text-capitalize">
						 
						<ul class="font_14 footer_menu ">
							<h2 class="font_28 font_weight600">DESTINATIONS </h2>
						 
							<li><a href="index.php">Ilam </a></li>
							<li><a href="tos.php">Bhedetar</a></li>
							<li><a href="gallery.php">Nagarkot</a></li>
							<li><a href="contact.php">Pokhara</a></li>
							<li><a href="news.php">Mustang</a></li>
							<li><a href="">Muktinath</a></li>
						</ul>
						<!-- <form action="" method="post" class="form form-horizontal">
							<div class="row form-group">
								<div class="col-lg-6 col-md-6 col-sm-12 p_tb5">
									<input type="text" placeholder="Full Name" required class="form-control form-control-sm rounded-0">
								</div>
								<div class="col-lg-6 col-md-6 col-sm-12 p_tb5">
									<input type="text" placeholder="Phone" required class="form-control form-control-sm rounded-0">
								</div>
								<div class="col-lg-12 col-md-12 col-sm-12 p_tb5">
									<input type="email" placeholder="Email Address" required class="form-control form-control-sm rounded-0">
								</div>
								<div class="col-lg-12 col-md-12 col-sm-12 p_tb5">
									<textarea name="message" id="message" rows="3" required class="form-control form-control-sm rounded-0 no-resize" placeholder="Your message Here"></textarea>
								</div>
								<div class="col-lg-12 col-md-12 col-sm-12 p_tb5 float-right text-right">
									<button class="btn feedbackUs  rounded-0">send feedback</button>
								</div>

							</div>
						</form> -->
					</div>
					
					<div class="col-lg-3 col-md-6 col-sm-12 text-capitalize">
						<ul class="font_14 footer_menu ">
							<h2 class="font_28 font_weight600">QUICK LINKS</h2>
						 
							<li><a href="index.php">about us </a></li>
							<li><a href="tos.php">our Terms</a></li>
							<li><a href="gallery.php">Gallery</a></li>
							<li><a href="contact.php">contact us</a></li>
							<li><a href="news.php">Teams</a></li>
							<li><a href="flights.php">Destinations</a></li>
						</ul>
					</div>
					<div class="col-lg-3 col-md-6 col-sm-12 text-capitalize">
						<iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FKINGofTROLL2017%2F&tabs=timeline&width=250&height=300&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId=692183977832781" width="250" height="300" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true" allow="encrypted-media"></iframe>
					</div>

					<div class="col-lg-3 col-md-6 col-sm-12 text-capitalize">
						<h2 class="font_28 white font_weight600">CONTACT INFO</h2>
						<h3 class="font_weight600 font_18 white">
							Tourism Nepal Adventure Tours & Travels Pvt. Ltd.
						</h3>
						<ul class="font_14">
						 
							<li >
								<a href="index.php" class="white"> 
									<span class="fa fa-map-marker"></span> 
									Kathmandu Nepal 
								</a>
							</li>
							<li >
								<a href="index.php" class="white"> 
									<span class="fa fa-phone"></span> 
									(+977) 14-244455, 14-244456  
								</a>
							</li>
							<li >
								<a href="index.php" class="white"> 
									<span class="fa fa-mobile"></span> 
									(+977)  9846-641469, 9851-011125
								</a>
							</li>
							<li >
								<a href="index.php" class="white"> 
									<span class="fa fa-envelope"></span> 
									info@nepaladventure.com
								</a>
							</li>
							 
						</ul>
						<h3 class="font_16 font_weight600 white m_t15">follow us on: </h3>
						<ul class="display_inline footer-last-social-link">
							<li class="m_r10">
								<a href="">
									<span class="facebook m_r5 font_28 fa fa-facebook"></span>
								</a>
							</li>
							<li class="m_r10">
								<a href="">
									<span class="twitter m_r5 font_28 fa fa-twitter"></span>
								</a>
							</li>
							<li class="m_r10">
								<a href="">
									<span class="youtube m_r5 font_28 fa fa-youtube"></span>
								</a>
							</li>
							<li class="m_r10">
								<a href="">
									<span class="linkedin m_r5 font_28 fa fa-linkedin"></span>
								</a>
							</li>
						</ul>
					</div>
				</div>
				<div class="row border_top_footer">
					<div class="col-lg-6 col-md-6 col-sm-6">
						<p>
							<span class="copyrights-text font_13">© 2019 Copyrights Reserved at Tourism Nepal Adventure Tours & Travels</span>
						</p>
						
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 webhouse_nepal">
						<p>
							<span class="copyrights-text font_13">
								Designed & Developed by: <a href="https://webhousenepal.com" title="https://webhousenepal.com" target="_blank">webhousenepal.com</a>
							</span>
						</p>
					</div>
				</div>
			</div>
		</div>
		
	</div>

	 

	 
 
	 

     <!-- -----------------consult question with us----------------- -->
     
	<button class="scroltop"><span class="fa fa-angle-up" id="btn-vibrate"></span></button>


	<script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <!-- <script src="js/isotope.min.js"></script> -->
    <script src="js/lightbox.js"></script>
	<script src="js/owl.carousel.js"   type="text/javascript"></script>
	<script src="js/main.js" type="text/javascript"></script>
	 
</body>
</html>
<!-- <script>
	$(document).ready(function(){
		$('.main_menu').click(function(){
			$(this).has("ul").("display", "block");
		})
	})
</script> -->
 				