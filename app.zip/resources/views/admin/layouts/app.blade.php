@include('admin.layouts._partials.header')

@include('admin.layouts._partials.left-sidebar')
<div class="content-wrapper">

@yield('content')

</div>


@include('admin.layouts._partials.footer')
